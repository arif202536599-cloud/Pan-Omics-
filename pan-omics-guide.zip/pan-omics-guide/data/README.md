# data/

Put downloaded genomes, proteomes and metadata here. Everything except this file is ignored by git
(see `.gitignore`). Record where every file came from in `templates/metadata_template.csv`.
