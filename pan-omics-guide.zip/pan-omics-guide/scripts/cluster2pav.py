#!/usr/bin/env python3
"""Turn an MMseqs2/CD-HIT-style cluster table into a presence/absence (PAV) matrix.

Input : two-column TSV, representative<TAB>member (MMseqs2 `*_cluster.tsv`).
        Member IDs must start with the genome name followed by a separator, e.g.  GENOME|protein_id
        (set the separator with --sep; default '|').
Output: TSV, rows = clusters (named by representative), columns = genomes, values 0/1.
        With --counts the values are copy numbers instead.

Usage : python cluster2pav.py clu_cluster.tsv --out pav.tsv
"""
import argparse
import sys
import pandas as pd


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("clusters")
    ap.add_argument("--out", default="pav.tsv")
    ap.add_argument("--sep", default="|")
    ap.add_argument("--counts", action="store_true")
    a = ap.parse_args()

    df = pd.read_csv(a.clusters, sep="\t", header=None, names=["rep", "member"], dtype=str)
    bad = ~df["member"].str.contains(a.sep, regex=False)
    if bad.any():
        sys.exit(f"{bad.sum()} IDs lack the separator '{a.sep}', e.g. {df.loc[bad, 'member'].iloc[0]}")
    df["genome"] = df["member"].str.split(a.sep, n=1, regex=False).str[0]
    pav = pd.crosstab(df["rep"], df["genome"])
    if not a.counts:
        pav = (pav > 0).astype(int)
    pav.index.name = "family"
    pav.to_csv(a.out, sep="\t")
    print(f"clusters: {pav.shape[0]}  genomes: {pav.shape[1]}  -> {a.out}")


if __name__ == "__main__":
    main()
