#!/usr/bin/env python3
"""Pan/core growth curves and Heaps' law fit (Tettelin approach).

For each random order of genomes, track pan-genome size and core size as genomes are added,
and the number of NEW families contributed by genome N. Fit  n = k * N^(-alpha)  by log-log
regression on the mean new-gene curve (N = 2..G).

  alpha < 1 : open pan-genome      alpha > 1 : closed pan-genome

Input : 0/1 presence/absence table (rows = families, columns = genomes, first column = names).
Output: <out>_curves.tsv, <out>_fit.txt and <out>_curves.png (if matplotlib is installed).

Usage : python heaps_law.py gene_presence_absence.Rtab --perms 100 --seed 1 --out results/heaps
Caveat: results depend on sampling and clustering. Do not interpret alpha with fewer than ~10 genomes.
"""
import argparse
import sys
import numpy as np
import pandas as pd


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("matrix")
    ap.add_argument("--perms", type=int, default=100)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--out", default="heaps")
    a = ap.parse_args()

    sep = "\t" if a.matrix.endswith((".Rtab", ".tsv", ".txt")) else ","
    df = pd.read_csv(a.matrix, sep=sep, index_col=0)
    X = (df.fillna(0).values > 0)          # families x genomes, boolean
    X = X[X.any(axis=1)]                    # drop empty families
    G = X.shape[1]
    if G < 3:
        sys.exit("Need at least 3 genomes.")
    rng = np.random.default_rng(a.seed)

    pan = np.zeros((a.perms, G))
    core = np.zeros((a.perms, G))
    new = np.zeros((a.perms, G))
    for p in range(a.perms):
        order = rng.permutation(G)
        Y = X[:, order]
        cum = np.cumsum(Y, axis=1)                       # presence counts as genomes are added
        pan[p] = (cum > 0).sum(axis=0)
        core[p] = (cum == np.arange(1, G + 1)).sum(axis=0)
        new[p, 0] = pan[p, 0]
        new[p, 1:] = np.diff(pan[p])

    N = np.arange(1, G + 1)
    curves = pd.DataFrame({
        "genomes": N,
        "pan_mean": pan.mean(0), "pan_sd": pan.std(0),
        "core_mean": core.mean(0), "core_sd": core.std(0),
        "new_mean": new.mean(0), "new_sd": new.std(0)})
    curves.to_csv(f"{a.out}_curves.tsv", sep="\t", index=False)

    # Fit on N >= 2 with positive means
    mask = (N >= 2) & (new.mean(0) > 0)
    slope, intercept = np.polyfit(np.log(N[mask]), np.log(new.mean(0)[mask]), 1)
    alpha, k = -slope, float(np.exp(intercept))
    # permutation range: fit each permutation separately
    alphas = []
    for p in range(a.perms):
        mp = (N >= 2) & (new[p] > 0)
        if mp.sum() >= 3:
            s, _ = np.polyfit(np.log(N[mp]), np.log(new[p][mp]), 1)
            alphas.append(-s)
    lo, hi = (np.percentile(alphas, 2.5), np.percentile(alphas, 97.5)) if alphas else (float("nan"),) * 2
    verdict = "open (alpha < 1)" if alpha < 1 else "closed (alpha >= 1)"
    text = (f"genomes={G} families={X.shape[0]} permutations={a.perms}\n"
            f"alpha={alpha:.3f}  95% permutation range=({lo:.3f}, {hi:.3f})  k={k:.1f}\n"
            f"pan-genome: {verdict}\n"
            f"final pan size={int(pan.mean(0)[-1])}  final core size={int(core.mean(0)[-1])}\n")
    open(f"{a.out}_fit.txt", "w").write(text)
    print(text)

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(1, 2, figsize=(10, 4))
        ax[0].plot(N, curves.pan_mean, label="pan"); ax[0].plot(N, curves.core_mean, label="core")
        ax[0].fill_between(N, curves.pan_mean - curves.pan_sd, curves.pan_mean + curves.pan_sd, alpha=.2)
        ax[0].fill_between(N, curves.core_mean - curves.core_sd, curves.core_mean + curves.core_sd, alpha=.2)
        ax[0].set_xlabel("genomes"); ax[0].set_ylabel("gene families"); ax[0].legend()
        ax[1].loglog(N[mask], curves.new_mean[mask], "o", label="mean new families")
        ax[1].loglog(N[mask], k * N[mask] ** (-alpha), label=f"fit, alpha={alpha:.2f}")
        ax[1].set_xlabel("genome number N"); ax[1].set_ylabel("new families"); ax[1].legend()
        fig.tight_layout(); fig.savefig(f"{a.out}_curves.png", dpi=200)
    except ImportError:
        print("matplotlib not installed; skipped plot")


if __name__ == "__main__":
    main()
