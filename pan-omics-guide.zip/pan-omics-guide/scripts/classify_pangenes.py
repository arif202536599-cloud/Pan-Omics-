#!/usr/bin/env python3
"""Classify gene families as core, soft core, shell, cloud (and private).

Input : presence/absence table, tab- or comma-separated. Rows = gene families,
        columns = genomes, values 0/1 (or counts; any value > 0 counts as present).
        The first column holds the family name (Panaroo/Roary .Rtab works as is).
Output: <out>_summary.tsv (counts per category) and <out>_per_gene.tsv.

Usage : python classify_pangenes.py gene_presence_absence.Rtab --out results/categories
Default thresholds follow Roary/Panaroo: core >= 99%, soft core >= 95%, shell >= 15%, else cloud.
"""
import argparse
import sys
import pandas as pd


def read_matrix(path):
    sep = "\t" if path.endswith((".Rtab", ".tsv", ".txt")) else ","
    df = pd.read_csv(path, sep=sep, index_col=0)
    return (df.fillna(0) > 0).astype(int)


def classify(freq, core, softcore, shell, n_genomes):
    labels = []
    for f in freq:
        if f * n_genomes <= 1.0 + 1e-9:
            labels.append("private")          # present in exactly one genome
        elif f >= core:
            labels.append("core")
        elif f >= softcore:
            labels.append("soft_core")
        elif f >= shell:
            labels.append("shell")
        else:
            labels.append("cloud")
    return labels


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("matrix")
    ap.add_argument("--out", default="categories")
    ap.add_argument("--core", type=float, default=0.99)
    ap.add_argument("--softcore", type=float, default=0.95)
    ap.add_argument("--shell", type=float, default=0.15)
    a = ap.parse_args()

    m = read_matrix(a.matrix)
    m = m[m.sum(axis=1) > 0]          # drop families absent from every genome
    n = m.shape[1]
    if n < 2:
        sys.exit("Need at least 2 genomes.")
    freq = m.sum(axis=1) / n
    cat = classify(freq.values, a.core, a.softcore, a.shell, n)
    per_gene = pd.DataFrame({"family": m.index, "n_genomes": m.sum(axis=1).values,
                             "frequency": freq.values, "category": cat})
    per_gene.to_csv(f"{a.out}_per_gene.tsv", sep="\t", index=False)
    summary = per_gene["category"].value_counts().reindex(
        ["core", "soft_core", "shell", "cloud", "private"], fill_value=0).rename("families")
    summary.to_csv(f"{a.out}_summary.tsv", sep="\t", header=True)
    print(f"genomes: {n}  families: {m.shape[0]}")
    print("note: 'private' = present in exactly one genome and is NOT included in the cloud count.")
    print(summary.to_string())


if __name__ == "__main__":
    main()
