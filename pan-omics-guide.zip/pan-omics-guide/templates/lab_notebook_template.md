# Lab notebook entry

- **Date / author:**
- **Project and question:**
- **Strain or accession IDs (match metadata.csv):**
- **Source of material and permit / MTA reference:**
- **Aim of this experiment:**
- **Hypothesis from analysis (gene family ID, prediction):**
- **Method (kit, lot number, volumes, temperatures, cycles):**
- **Controls (positive, negative, no template, internal control):**
- **Replicates (biological / technical):**
- **Raw data location (gel image, Ct file, raw MS file):**
- **Result:**
- **Agreement with prediction:** yes / no / ambiguous
- **If no: possible causes and next step:**
