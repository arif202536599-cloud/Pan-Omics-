# Genome selection checklist

- [ ] Research question written down
- [ ] Species boundary defined (ANI cutoff: ____)
- [ ] Source databases listed and accessions saved
- [ ] Assembly level rule: ____
- [ ] Completeness >= ____ and contamination <= ____
- [ ] Contig count <= ____ ; genome size within ____ % of median
- [ ] Near-identical clones removed (ANI >= ____)
- [ ] Outgroup chosen: ____
- [ ] Same annotation tool and version for every genome: ____
- [ ] Every exclusion logged with a reason
- [ ] Parameters and cutoffs pre-registered in the notebook before analysis
