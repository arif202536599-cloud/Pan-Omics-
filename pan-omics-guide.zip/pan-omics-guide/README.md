# Pan-omics guide: pan-genome and pan-proteome, from zero to expert

A practical, step-by-step repository that takes you from the first question
("which genomes do I include?") to publication-ready analysis and bench validation.

It covers three connected parts:

| Part | What it covers |
| --- | --- |
| **Pan-genome** | study design, retrieval and selection, QC, annotation, construction, analysis, graph pangenomes and structural variants |
| **Pan-proteome** | sequence-level pan-proteomes, mass-spectrometry pan-proteomics, domain and structure level analysis |
| **Wet lab** | sampling, DNA/RNA/protein work, PCR and qPCR validation, functional assays, proteomics sample prep, data sharing |

## How to use this repository

1. Start with [`docs/00-roadmap-zero-to-expert.md`](docs/00-roadmap-zero-to-expert.md) and pick your level.
2. Read [`docs/01-foundations.md`](docs/01-foundations.md) for definitions, thresholds and the environment.
3. Follow the pan-genome or pan-proteome folder in numbered order.
4. Run the matching script in `workflows/`, then use `scripts/` for the analysis.
5. Take your predictions to the bench with `docs/wet-lab/`.
6. Fill in the files in `templates/` as you go, so the project stays reproducible.

## Layout

```
pan-omics-guide/
├── README.md
├── environment.yml              conda environment with the main tools
├── docs/
│   ├── 00-roadmap-zero-to-expert.md
│   ├── 01-foundations.md
│   ├── 02-cheatsheet.md
│   ├── pangenome/               01 design -> 07 reporting
│   ├── pan-proteome/            01 concepts -> 05 structure and networks
│   └── wet-lab/                 01 bioinformatics-to-bench -> 05 safety and sharing
├── workflows/
│   ├── pangenome_bacteria/      numbered shell scripts, 01 to 05
│   ├── pangenome_eukaryote/     plant and animal workflow notes
│   └── pan_proteome/            UniProt fetch, clustering, OrthoFinder
├── scripts/                     Python: Heaps' law, gene classification, cluster to PAV matrix
├── templates/                   metadata sheet, selection checklist, primer table, notebook
└── data/                        put your inputs here (not tracked by git)
```

## Before you publish

- Tool flags change between versions. Run `<tool> --help` and pin versions in `environment.yml`.
- Check every reference in the docs against the original paper.
- Choose a license (for example CC BY 4.0 for text and MIT for code) and add a `LICENSE` file.
- Never commit raw reads, patient data or personal contact lists. See `docs/wet-lab/05-safety-ethics-data-sharing.md`.
