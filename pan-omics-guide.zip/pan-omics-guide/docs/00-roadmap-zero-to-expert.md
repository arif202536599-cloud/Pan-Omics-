# Roadmap: zero to expert

Each level has a goal, what to learn, a mini-project, and a check you can pass before moving on.
Times assume 6 to 10 hours a week and are rough.

## Level 0: Prerequisites (2 to 4 weeks)

- **Learn:** Linux shell (`cd`, `grep`, `awk`, `sed`, pipes), conda, Git, FASTA/FASTQ/GFF3 formats, basic Python or R.
- **Project:** download one bacterial genome, count its contigs and genes with `seqkit` and `grep -c`.
- **Check:** you can explain what a FASTA header, a GFF3 line and a Phred score are.

## Level 1: Concepts (2 weeks)

- **Learn:** core, accessory and pan-genome; open versus closed pan-genomes; orthologs versus paralogs; why annotation consistency matters.
- **Read:** `docs/01-foundations.md` and the Tettelin 2005 and 2008 papers.
- **Project:** draw by hand the presence/absence matrix for 5 genomes and 6 gene families, then count core, shell and cloud.
- **Check:** you can say why a missing gene in one genome may be a pipeline artifact and not biology.

## Level 2: Run a bacterial pan-genome (4 weeks)

- **Learn:** `docs/pangenome/01` to `05`; the five scripts in `workflows/pangenome_bacteria/`.
- **Project:** 20 to 50 genomes of one species, from download to core-gene tree and Heaps' law curve.
- **Check:** your results table lists genome count, core size, accessory size, alpha, and QC exclusions with reasons.

## Level 3: Analysis depth (6 to 8 weeks)

- **Learn:** functional enrichment, recombination (Gubbins), gene-trait association (Scoary, pyseer), mobile elements, AMR and virulence genes.
- **Project:** pick a phenotype (for example resistance to one antibiotic) and test which accessory genes associate with it, correcting for population structure.
- **Check:** you can explain why raw Fisher tests on accessory genes give false positives without phylogeny correction.

## Level 4: Pan-proteome and proteomics (6 to 8 weeks)

- **Learn:** `docs/pan-proteome/01` to `05`; clustering proteins; mass-spectrometry search databases; FDR.
- **Project:** build a pan-proteome FASTA from your pan-genome and use it as the search database for a public PRIDE dataset.
- **Check:** you can explain the shared-peptide problem and how it affects protein-level claims.

## Level 5: Eukaryotes, graphs and structural variants (8 to 12 weeks)

- **Learn:** `docs/pangenome/06`; Minigraph-Cactus or PGGB; PAV from reads; long-read assembly; plant genome annotation.
- **Project:** build a small graph pangenome of a region (for example one chromosome of several accessions) and call structural variants.
- **Check:** you can say when a linear reference is enough and when a graph is justified.

## Level 6: Bench validation and expert practice (ongoing)

- **Learn:** `docs/wet-lab/`; PAV PCR, RT-qPCR, knockouts, complementation, targeted proteomics.
- **Project:** validate three predicted presence/absence calls by PCR and one expression call by RT-qPCR.
- **Check:** your methods are reproducible: every software version, primer sequence, and sample ID is recorded.
- **Expert habits:** pre-register your selection criteria, keep a negative-results log, test every conclusion with a second method, and release code and data with your paper.
