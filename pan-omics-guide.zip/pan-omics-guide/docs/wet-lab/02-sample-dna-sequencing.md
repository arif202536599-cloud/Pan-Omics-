# 2. Samples, DNA and sequencing

## Sample handling

- Use **single colonies or single plants** with a recorded ID. Mixed cultures give mixed genomes.
- Record source, date, growth medium and conditions, and passage number (bacteria).
- Freeze stocks (bacteria in glycerol at about minus 80 C). Keep tissue for plants flash-frozen in liquid nitrogen.
- Confirm species before sequencing (16S PCR or a quick MALDI-TOF or ANI check).

## DNA extraction

| Goal | Approach |
| --- | --- |
| Short-read sequencing | standard kit extraction (bacteria: lysozyme plus kit; plants: CTAB or a plant kit) |
| Long-read sequencing | high-molecular-weight (HMW) DNA: gentle lysis, avoid vortexing, wide-bore tips, no heavy shearing |
| Plants with high polysaccharides or polyphenols | CTAB with PVP, extra clean-up (for example size-selective beads) |

## DNA QC (do this every time)

1. **Purity:** NanoDrop A260/280 near 1.8 and A260/230 above about 2.0.
2. **Quantity:** Qubit (more accurate than NanoDrop).
3. **Integrity:** agarose gel, or TapeStation or Femto Pulse for fragment size.
4. Only sequence samples that pass your platform's minimum.

## Choosing a platform

| Platform | Strength | Use |
| --- | --- | --- |
| Illumina short reads | cheap, accurate | polishing, SNPs, PAV by mapping |
| Oxford Nanopore | long reads, fast, flexible | complete bacterial genomes, SVs |
| PacBio HiFi | long and accurate | high-quality assemblies and SVs |
| Hybrid | long plus short | complete, polished bacterial genomes |
| Hi-C or optical maps | scaffolding | chromosome-scale plant genomes |

## Assembly basics

- Bacteria: Flye or Unicycler (hybrid), then polish (Medaka or Pilon). Check circularity of chromosome and plasmids.
- Plants and large genomes: hifiasm with HiFi (and Hi-C), then scaffolding and gap checks.
- Always check with BUSCO or CheckM2, read mapping coverage, and contamination screens.

## RNA and protein samples (for later steps)

- RNA: extract with a column or TRIzol method, DNase treat, check RIN or integrity on a gel. Keep RNase-free technique.
- Protein: see `04-proteomics-sample-prep-and-validation.md`.

## Deposit raw data

Submit reads to SRA (BioProject and BioSample metadata) with the same IDs used in your genome table.
