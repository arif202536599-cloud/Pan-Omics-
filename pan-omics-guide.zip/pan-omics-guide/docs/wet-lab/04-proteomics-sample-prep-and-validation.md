# 4. Proteomics sample prep and validation

## Sample preparation for LC-MS/MS (bottom-up)

1. **Harvest** cells or tissue at a defined condition. Wash to remove medium. Flash freeze.
2. **Lyse** in a compatible buffer (for example SDS with heating, urea, or detergent with sonication or bead beating). Keep protease inhibitors on.
3. **Quantify** protein (BCA or similar) and use equal input per sample.
4. **Reduce and alkylate** cysteines (DTT then iodoacetamide).
5. **Digest** with trypsin (often with Lys-C), commonly overnight at 37 C. Use a clean-up method suited to your lysis buffer (S-Trap, SP3, or FASP).
6. **Desalt** peptides on C18 and dry or keep in formic acid.
7. **Add controls:** pooled QC sample and, if used, spike-in standard peptides for retention-time and quantification checks.
8. **Run** DDA or DIA with randomized injection order.

Avoid keratin contamination (gloves, clean surfaces, no wool). Avoid detergents that are not removable.

## Enrichment options

- Subcellular fractions (membrane, secretome, periplasm) for localization-focused pan-proteomes.
- PTM enrichment (phosphopeptides by TiO2 or IMAC) when studying signalling.

## Orthogonal protein validation

| Method | Use | Key points |
| --- | --- | --- |
| Western blot | confirm one protein | needs a specific antibody; include loading control; test antibody on a knockout |
| Targeted MS (PRM or SRM) | validate many candidates without antibodies | choose 2 to 3 unique peptides per protein, use heavy-labelled standards if possible |
| Epitope tagging | track the protein when no antibody exists | check tag does not change function |
| ELISA | quantify secreted or surface proteins | needs paired antibodies |
| Enzyme activity assay | function of an enzyme | include no-substrate and heat-inactivated controls |

## Choosing peptides for targeted MS

- Prefer peptides unique to the target protein group (check against the pan-proteome).
- Avoid peptides with methionine, N-terminal glutamine or cysteine when possible (variable modification).
- Length 7 to 25 residues, good ionization, no missed cleavages.

## Link to the pan-proteome

For each validated protein, record: family ID, strain, peptides used, method, and result. Add it to the
per-family table (`docs/pan-proteome/05`).
