# 1. From bioinformatics to the bench

Computational results are hypotheses. The bench turns them into evidence.

## The loop

```
design -> sample -> sequence -> analyse -> predict -> validate at the bench -> refine -> publish
```

## What to validate, and how

| Computational claim | Bench test | Doc |
| --- | --- | --- |
| Gene present or absent in a strain | PCR with flanking primers, Sanger sequencing | `03` |
| Gene expressed | RT-qPCR or RNA-seq | `03` |
| Gene needed for a trait | knockout, complementation, overexpression, phenotype assay | `03` |
| Protein made | Western blot, targeted MS (PRM/SRM) | `04` |
| Structural variant exists | long-read sequencing, PCR across breakpoints | `03` |
| Gene confers resistance | MIC test or growth assay with and without the gene | `03` |

## Prioritize candidates

Rank by: effect size and statistics, conservation within a lineage, functional annotation, feasibility of
the assay, and whether you already have the strains. Validate a small, well-chosen set, include positive and
negative controls, and say clearly which genes were tested and which were not.

## Planning checklist

- Do you have the physical strains or accessions? Where from, with what permissions?
- Which positive control (gene known present) and negative control (gene known absent)?
- Replicates: biological, not only technical.
- Approvals: biosafety, ethics, plant material permits, material transfer agreements (`05`).
- Budget and timeline for each assay.

## Lab records

Use `templates/lab_notebook_template.md`. Record strain IDs that match the genome IDs in your metadata, so every
bench result can be traced to the exact sequence.
