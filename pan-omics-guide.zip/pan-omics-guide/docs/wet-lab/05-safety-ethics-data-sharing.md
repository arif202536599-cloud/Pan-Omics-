# 5. Safety, ethics and data sharing

## Biosafety and permits

- Work at the biosafety level appropriate to the organism and follow your institution's approval process.
- Pathogens, select agents, GMOs and CRISPR constructs need institutional biosafety committee approval and local regulations.
- Plant or animal materials may need collection permits and phytosanitary or import documents.
- Keep waste handling and decontamination procedures written and followed.

## Access and benefit sharing

- Genetic resources from other countries can fall under the Nagoya Protocol and national access rules.
- Use material transfer agreements (MTAs) where required. Record the source and permissions.

## Human and personal data

- Do not publish personal data (names, emails, phone numbers) of collaborators, users, or patients in a public repository.
- Clinical isolates and host sequences may be subject to consent and privacy rules. Remove host reads before sharing human-derived data.
- If a file with personal data was ever committed, deleting it is not enough: the data remains in git history. Remove it with a history-rewrite tool and rotate any exposed secrets.

## Data sharing and FAIR practice

| Data | Where |
| --- | --- |
| Raw reads | SRA or ENA, linked to BioProject and BioSample |
| Assemblies and annotations | GenBank or ENA, and Zenodo for derived tables |
| Proteomics raw and results | PRIDE (ProteomeXchange) |
| Code | GitHub, archived with a DOI on Zenodo |
| Methods and protocols | protocols.io or the supplement |

Use stable accessions in the paper. Include a data availability statement and a software availability statement.

## Responsible conduct

- Record negative results.
- Keep original gel images and raw instrument files.
- Credit tools and datasets with citations.
- Be careful when claiming causality from association. Validate before you claim.

## References (verify details before citing)

- Tettelin et al. 2005, PNAS: the pan-genome concept in *Streptococcus agalactiae*.
- Tettelin et al. 2008, Current Opinion in Microbiology: bacterial pan-genome review.
- Page et al. 2015, Bioinformatics: Roary.
- Tonkin-Hill et al. 2020, Genome Biology: Panaroo.
- Gautreau et al. 2020, PLoS Computational Biology: PPanGGOLiN.
- Emms and Kelly 2019, Genome Biology: OrthoFinder.
- Steinegger and Soding 2017, Nature Biotechnology: MMseqs2.
- Manni et al. 2021, Molecular Biology and Evolution: BUSCO.
- Chklovski et al. 2023, Nature Methods: CheckM2.
- Shaw and Yu 2023, Nature Methods: skani.
- Schwengers et al. 2021, Microbial Genomics: Bakta.
- Brynildsrud et al. 2016, Genome Biology: Scoary.
- Lees et al. 2018, Bioinformatics: pyseer.
- Hickey et al. 2023, Nature Biotechnology: Minigraph-Cactus.
- Garrison et al. 2024, Nature Methods: pangenome graph building (PGGB).
- Perez-Riverol et al. 2022, Nucleic Acids Research: PRIDE.
- Bustin et al. 2009, Clinical Chemistry: MIQE guidelines.
