# 3. Validating pan-genome predictions

## 3.1 PCR validation of presence/absence

Goal: show a gene is truly present or truly absent in each strain.

**Primer design**

1. Take the gene or region sequence from `pan_genome_reference.fa`.
2. Design primers with Primer3: amplicon 150 to 500 bp for a quick test, Tm about 58 to 62 C, GC 40 to 60%, avoid hairpins and primer-dimers.
3. Check specificity with BLAST against all your genomes (including those where the gene is predicted absent).
4. Use `templates/primer_design_table.csv` to record sequences, expected sizes and results.

**Two kinds of design**

- **Internal primers:** amplify inside the gene. A band means present. No band could mean absent or primer mismatch.
- **Flanking primers (stronger for absence):** sit in conserved sequence on both sides of the locus. A product with the gene is large. A smaller product (or none of the large size) shows a deletion. Gives a positive result for both states.

**Controls (always)**

- Positive control: strain known to carry the gene.
- Negative control: strain known to lack the gene, and a no-template control.
- **Internal amplification control:** a conserved housekeeping gene (for example a 16S fragment for bacteria) in every sample, so a failed PCR is not read as "absent".

**Run**

- 20 to 25 ul PCR with a proofreading or standard polymerase as needed, 30 to 35 cycles, annealing near primer Tm minus 3 to 5 C.
- Gel: agarose 1 to 2%, include a size ladder.
- Sanger-sequence a subset of bands to confirm identity.

Record results as a table (strain by gene: +, minus, ambiguous) and compare with the computational matrix. Report the agreement rate and explain disagreements (for example primer site variation, partial genes).

## 3.2 Expression validation: RT-qPCR

1. Extract RNA, DNase treat, check integrity, make cDNA with a fixed input amount.
2. Include no-RT controls to detect genomic DNA carry-over.
3. Choose at least two stable reference genes and test their stability across conditions.
4. Check primer efficiency (90 to 110% by standard curve) and melt-curve specificity.
5. Calculate relative expression (delta-delta Ct) with at least 3 biological replicates and appropriate statistics.
6. Follow MIQE reporting guidelines.

For many genes, use RNA-seq and align reads to the pan-genome to quantify accessory genes too.

## 3.3 Structural variant validation

- Design PCR across predicted breakpoints (product exists only if the variant is present).
- Or long-read sequencing of the locus (Nanopore or HiFi) and visual check in IGV.
- Sanger sequencing across breakpoints gives base-level confirmation.

## 3.4 Functional validation

| Approach | Bacteria | Plants |
| --- | --- | --- |
| Loss of function | allelic exchange, CRISPR or recombineering knockout | CRISPR-Cas9 mutants, T-DNA lines, TILLING |
| Gain of function | plasmid expression, chromosomal insertion | overexpression, transient expression (for example in Nicotiana benthamiana) |
| Complementation | put the gene back on a plasmid or in the chromosome | transform mutant with the wild-type allele |
| Natural variation | compare strains or accessions with and without the gene | compare lines, near-isogenic lines |

Logic: a gene is linked to a trait when removing it removes the trait and putting it back restores it.

**Phenotype assays (examples)**

- Antimicrobial resistance: broth microdilution MIC following CLSI or EUCAST methods, with quality-control strains.
- Growth: growth curves (OD600) in defined media with replicates.
- Biofilm: crystal violet assay, or microscopy.
- Virulence or colonization: cell-culture or approved animal or plant infection models.
- Plants: controlled growth chamber or field trials with randomized design, blind scoring, and enough replicates.

## 3.5 Statistics for the bench

- Pre-define the hypothesis and primary readout.
- Use biological replicates (independent cultures or plants). Technical replicates only check pipetting.
- Report effect sizes and confidence intervals, not only p-values.
- Share raw gel images and Ct tables.

## 3.6 Closing the loop

If a prediction fails, check: sequence errors in the genome, primer mismatch, mislabeled strain, annotation
error, or real biology. Update the computational pipeline when you find a systematic cause.
