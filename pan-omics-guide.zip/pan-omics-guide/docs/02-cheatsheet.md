# Cheatsheet

| Task | Command (verify flags with `--help`) |
| --- | --- |
| Download genomes by taxon | `datasets download genome taxon "Escherichia coli" --assembly-level complete --assembly-source RefSeq --include genome,gff3,protein --dehydrated --filename ec.zip` |
| Rehydrate after unzip | `datasets rehydrate --directory ec/` |
| Sequence stats | `seqkit stats -a genomes/*.fna` |
| ANI matrix | `skani triangle -t 8 genomes/*.fna -o ani.txt` |
| Completeness | `checkm2 predict -t 8 -x fna --input genomes/ --output-directory checkm2_out` |
| Annotate | `bakta --db db --threads 8 --prefix NAME --output ann/NAME genome.fna` |
| Pan-genome (Panaroo) | `panaroo -i gffs/*.gff -o panaroo_out --clean-mode strict -t 8` |
| Pan-genome (PPanGGOLiN) | `ppanggolin workflow --anno genomes.tsv --output pp_out --cpu 8` |
| Protein clustering | `mmseqs easy-cluster all.faa clu tmp --min-seq-id 0.9 -c 0.8 --cov-mode 0` |
| Orthogroups | `orthofinder -f proteomes/ -t 16 -a 4` |
| Align | `mafft --auto --thread 8 in.fa > out.aln` |
| Tree | `iqtree2 -s core.aln -m MFP -B 1000 -T AUTO` |
| Recombination | `run_gubbins.py --prefix g core.aln` |
| Gene-trait association | `scoary -g gene_presence_absence_roary.csv -t traits.csv` |
| Function | `emapper.py -i reps.faa -o eggnog --cpu 8 --data_dir eggnog_db` |
| Primer design | `primer3_core < primer3_input.txt` |
