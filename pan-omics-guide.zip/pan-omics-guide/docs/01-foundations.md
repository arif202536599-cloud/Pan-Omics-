# Foundations

## Definitions

- **Pan-genome:** the full set of gene families found across a defined group of genomes (a species, a clade, a cultivar panel).
- **Core genome:** gene families present in all, or nearly all, genomes.
- **Accessory (dispensable) genome:** present in some genomes. Split into **shell** and **cloud**.
- **Private (singleton) genes:** found in exactly one genome.
- **Open pan-genome:** each new genome keeps adding new gene families. **Closed:** additions level off.
- **Pan-proteome:** the set of protein families (or experimentally detected proteins) across the same group. See `docs/pan-proteome/01`.
- **PAV:** presence/absence variation. **SV:** structural variant (insertion, deletion, inversion, translocation, copy-number change).
- **Ortholog:** genes separated by a speciation event. **Paralog:** separated by duplication.

## Common category thresholds

These are conventions (Roary and Panaroo defaults), not laws. State yours in the methods.

| Category | Present in |
| --- | --- |
| Core | 99% to 100% of genomes |
| Soft core | 95% to 99% |
| Shell | 15% to 95% |
| Cloud | under 15% |

PPanGGOLiN uses a statistical partition model (persistent, shell, cloud) instead of fixed cutoffs.

## Rules that prevent the most common mistakes

1. **Annotate every genome with the same tool and database version.** Mixing GenBank annotations from different pipelines creates fake accessory genes.
2. **Fix the species boundary first.** Use ANI (about 95% for bacteria) so you do not mix species.
3. **Filter on quality before clustering.** Poor assemblies inflate the cloud genome.
4. **Report parameters.** Identity cutoff, coverage cutoff, thresholds, tool versions.
5. **Sampling bias matters.** Outbreak-heavy datasets look closed. Diverse sampling looks open.
6. **A gene absent from a draft assembly may simply be unassembled.** Check by mapping reads.

## Environment

```bash
conda env create -f environment.yml
conda activate panomics
```

Some packages (CheckM2, Bakta, eggNOG-mapper, BUSCO) need separate database downloads. Each workflow script
notes this. If one package fails to solve, install it in its own environment.

## Project layout for your own analysis

```
project/
├── data/raw/        untouched downloads
├── data/clean/      after QC
├── results/         tables and figures
├── work/            temporary files
├── logs/            one log per step
└── metadata.csv     one row per genome (see templates/)
```

## Reproducibility checklist

- Record every command or script in Git.
- Pin tool versions (`conda env export > env.lock.yml`).
- Save random seeds for permutations.
- Keep a metadata table with accession, source, date downloaded, and QC result for every genome.
