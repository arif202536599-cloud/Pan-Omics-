# 1. Concepts and design

## What "pan-proteome" means

The term is used in three ways. Say which one you mean.

1. **Sequence-level pan-proteome:** protein families clustered from the predicted proteomes of many genomes. Computed from sequences only. This is the closest to a pan-genome.
2. **Experimental pan-proteome:** proteins actually detected by mass spectrometry across strains, tissues or conditions. Tells you what is expressed, not just encoded.
3. **Domain or structure-level pan-proteome:** presence/absence of protein domains (Pfam) or folds across genomes, which stays stable when sequences diverge.

Most projects combine 1 and 2: build the sequence pan-proteome, then use it as the database for mass spectrometry.

## Pan-genome versus pan-proteome

| | Pan-genome | Pan-proteome |
| --- | --- | --- |
| Unit | gene family | protein family or detected protein |
| Based on | DNA and annotation | translated sequence, or MS evidence |
| Detects expression | no | yes (experimental) |
| Affected by splicing and isoforms | partly | strongly in eukaryotes |
| Noise source | annotation errors | annotation plus detection limits |

A protein absent from MS data is not necessarily absent from the genome. Low abundance, sample prep and
instrument depth all limit detection.

## Design questions

- Which proteomes? Same rules as `docs/pangenome/01` and `02`.
- Which isoform per gene (eukaryotes)? Usually the longest, or keep all for MS.
- Which clustering identity and coverage? Often 50% identity for broad families and 90% to 95% for strain-level variants.
- Will you add experimental evidence? If yes, plan sample types, replicates and instrument time now (`docs/wet-lab/04`).
- Which question? Core essential functions, strain-specific proteins, secreted proteins, vaccine candidates, stress-response proteins.

## Deliverable

A short plan: definition of pan-proteome you will use, proteome sources, clustering parameters, and whether MS is included.
