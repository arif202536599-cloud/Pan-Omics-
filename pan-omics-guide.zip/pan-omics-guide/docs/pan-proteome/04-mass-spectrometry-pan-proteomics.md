# 4. Mass-spectrometry pan-proteomics

## Experiment types

| Type | Idea | Use |
| --- | --- | --- |
| DDA (data-dependent) | instrument picks abundant ions for fragmentation | discovery, simple, widely supported |
| DIA (data-independent) | fragments everything in windows | better reproducibility across many samples |
| Targeted (PRM/SRM) | measure chosen peptides precisely | validate candidates (see `docs/wet-lab/04`) |
| TMT / SILAC | labelled quantification | multiplexed comparisons |

## Design

- **Replicates:** at least 3 biological replicates per condition; more for small effects.
- **Controls:** a pooled QC sample injected regularly; blanks between groups.
- **Randomize** injection order so batch is not confounded with condition.
- **Record** instrument, gradient, and method in the metadata.

## Search database

The database decides what you can see.

1. Build a **pan-proteome FASTA**: one representative per protein family, or all sequences from the strains you measured.
2. Add **common contaminants** (cRAP, keratin, trypsin).
3. Add the **host proteome** if samples contain host material.
4. Use **target-decoy** (reverse or shuffled) sequences for FDR.

Search with a strain-specific database when you know the strain. Search with the pan-proteome when you do
not, or when you want one database for many strains.

## Search and quantify

| Tool | Notes |
| --- | --- |
| MaxQuant | popular, DDA, label-free (LFQ, iBAQ) |
| FragPipe / MSFragger | fast, DDA and DIA |
| DIA-NN | DIA, library-free or library-based |
| Spectronaut | commercial DIA |

Settings to record: enzyme (usually trypsin, up to 2 missed cleavages), fixed modification (carbamidomethyl C),
variable modifications (oxidation M, protein N-terminal acetylation), precursor and fragment tolerances,
FDR (usually 1% at PSM, peptide and protein level).

## The shared-peptide problem

A peptide shared by several proteins (common in a pan-proteome with many close variants) cannot say which
protein is present.

- Report protein groups, not single proteins.
- Count **unique peptides** per protein group.
- Collapse near-identical variants into one family for protein-level claims, or use only unique peptides for variant-level claims.

## Statistics

1. Filter proteins by valid values (for example found in at least 70% of samples in one group).
2. Normalize (median, quantile, or vsn).
3. Handle missing values carefully. Separate "absent" (missing not at random) from random dropout.
4. Test with limma or MSstats and correct for multiple testing.
5. Plot PCA, volcano, and heatmaps.

## Link back to the pan-genome

- Annotate each detected protein with its pan-genome family.
- Core genes without protein evidence: check for low expression or sample limits.
- Accessory genes with strong protein evidence are strong candidates for function.
- Report the percentage of the pan-proteome detected, per sample type.

## Deposit

Upload raw files and search results to PRIDE (ProteomeXchange) before submission. Include the exact FASTA used.
