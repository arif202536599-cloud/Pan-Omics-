# 3. Construction and analysis

## Build protein families

Option A: MMseqs2 (fast, tunable)

```bash
cat clean/*.faa > all.faa
mmseqs easy-cluster all.faa clu tmp --min-seq-id 0.5 -c 0.8 --cov-mode 0 --threads 16
python scripts/cluster2pav.py clu_cluster.tsv --out pav.tsv
```

Option B: OrthoFinder (orthology-aware; better for eukaryotes and diverged species)

```bash
orthofinder -f clean/ -t 16 -a 4 -M msa
```

Option C: Proteinortho or SonicParanoid for large sets. For strain-level questions, use a high identity
(90% to 95%). For broad family questions, use 40% to 50% with coverage of 80%.

## Classify

```bash
python scripts/classify_pangenes.py pav.tsv --out results/categories
python scripts/heaps_law.py pav.tsv --perms 100 --out results/heaps
```

Treat the output as a pan-proteome presence/absence table with the same categories as the pan-genome.

## Compare with the pan-genome

- Where gene families and protein families disagree, check for frame-shifts, pseudogenes and annotation differences.
- Genes with DNA presence but no protein call often reveal truncated or mis-annotated genes.

## Functional characterisation

1. **Domains:** `hmmscan` against Pfam, or InterProScan. Build a domain presence/absence matrix.
2. **Function:** eggNOG-mapper for COG, KEGG, GO.
3. **Localization and secretion:** SignalP 6 (signal peptides), DeepTMHMM (transmembrane), DeepLoc 2 (localization).
4. **Enrichment:** core versus accessory protein sets with Fisher test and correction.
5. **Antigen or target mining:** keep proteins that are conserved (core), surface-exposed, and absent from the host proteome. Validate experimentally.

## Domain-level pan-proteome

A domain table is robust when sequences are too diverged to cluster. Count shared, variable and private
domains and report how many are lineage-specific.

## Statistics tips

- Use permutation tests for core and pan curves.
- Use phylogeny-aware tests for trait association (as in `docs/pangenome/05`).
- Report clustering parameters with every table.
