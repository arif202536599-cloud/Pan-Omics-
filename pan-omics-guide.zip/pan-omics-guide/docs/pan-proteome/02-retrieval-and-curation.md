# 2. Retrieval and curation

## Sources

| Source | Content |
| --- | --- |
| UniProt reference proteomes | curated, one proteome per organism, with BUSCO-based quality scores; IDs like `UP000000625` |
| UniProt pan-proteomes | species-level sets for some species (check availability on UniProt) |
| NCBI RefSeq / Datasets | protein FASTA per assembly (`--include protein`) |
| Ensembl / Ensembl Plants / Phytozome | eukaryote proteomes with gene and transcript links |
| Genome annotation you made | Bakta, Prokka or BRAKER output (`.faa`) |

## Fetch from UniProt

```bash
# one reference proteome by ID (replace UP000000625)
curl -s "https://rest.uniprot.org/uniprotkb/stream?query=(proteome:UP000000625)&format=fasta&compressed=false" \
  -o data/UP000000625.faa
```

The script `workflows/pan_proteome/01_fetch_uniprot.sh` loops over a list of proteome IDs.

## Curation steps

1. **Standardize IDs.** Prefix every sequence with the genome name: `GENOME|PROTEIN_ID`. This lets you map clusters back to genomes.
2. **Remove isoforms** (eukaryotes) unless you need them. Keep the longest per gene.
3. **Remove bad sequences:** very short (for example under 30 aa), internal stop codons, ambiguous residues (a lot of X).
4. **Check completeness** with BUSCO in protein mode: `busco -i proteome.faa -l LINEAGE -m proteins -o out`.
5. **Remove contaminants** by taxonomy search (DIAMOND against a reference database) if sources are mixed.
6. **Log everything** in the metadata sheet.

```bash
seqkit seq -m 30 in.faa | seqkit rmdup -s > clean.faa
```

## Quality traps

- Predicted proteomes from different pipelines differ in gene count and length. Re-annotate, or restrict to one pipeline.
- Pseudogenes and fragments inflate singletons.
- Very large proteomes include transposon-derived proteins. Decide whether to mask or keep them.

## Deliverable

One clean FASTA per genome with standard headers, a combined FASTA, and a log of removed sequences.
