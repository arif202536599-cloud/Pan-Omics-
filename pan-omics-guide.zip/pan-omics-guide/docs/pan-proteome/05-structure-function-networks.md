# 5. Structure, function and networks (expert)

## Structure

1. Fetch predicted structures from the AlphaFold Database for reference proteomes, or run ColabFold or AlphaFold for your own representatives.
2. Cluster by fold with Foldseek: structural clusters group proteins whose sequences diverged too far to cluster.
3. Compare sequence-level and structure-level pan-proteomes. Families merged by structure but split by sequence are candidates for remote homology.
4. Check pLDDT confidence. Do not interpret low-confidence regions as structure.

## Post-translational modification and regulation

- Search MS data with variable modifications (phosphorylation, acetylation) and a localization score filter.
- Report modifications as a separate layer, not as new proteins.

## Interaction networks

- Map families to STRING for known organisms and look at network modules enriched in accessory sets.
- Build co-presence networks: gene families that appear and disappear together often share a pathway or sit on the same mobile element.
- Cross-check with gene neighbourhood (operons, islands).

## Multi-omics integration

| Layer | Question |
| --- | --- |
| Genome | which genes exist |
| Transcriptome | which genes are expressed (RNA-seq) |
| Proteome | which proteins accumulate |
| Metabolome | what the pathway outputs are |

Align the layers on the pan-genome family IDs. Discordance between RNA and protein is common and meaningful
(translation control, protein stability).

## Target prioritization (vaccine, drug, marker)

Filter sequence families by: conservation (core), accessibility (surface or secreted), absence from host,
essentiality (literature or knock-out data), druggable structure. Then validate (`docs/wet-lab/03` and `04`).

## Deliverable

A table with, for each protein family: category, domains, localization, structure cluster, expression evidence, and validation status.
