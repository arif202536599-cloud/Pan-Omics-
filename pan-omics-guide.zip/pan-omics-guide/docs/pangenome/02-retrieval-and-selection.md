# 2. Retrieval and selection

## Where to get genomes

| Source | Use | Notes |
| --- | --- | --- |
| NCBI Datasets / RefSeq | most bacteria, archaea, eukaryotes | consistent annotation labels; `datasets` CLI |
| NCBI GenBank | broadest, includes non-RefSeq | check annotation source |
| GTDB | bacterial and archaeal taxonomy | use for clean species boundaries |
| Ensembl, Ensembl Plants, Phytozome | eukaryote genomes and annotations | check versions |
| BV-BRC, EnteroBase, PubMLST | pathogen genomes with metadata | rich phenotype data |
| SRA / ENA | raw reads | assemble yourself, see `workflows/` |
| Your own sequencing | new isolates or accessions | see `docs/wet-lab/02` |

## Download with NCBI Datasets

```bash
datasets download genome taxon "Escherichia coli" \
  --assembly-level complete --assembly-source RefSeq \
  --include genome,gff3,protein --dehydrated --filename ec.zip
unzip ec.zip -d ec && datasets rehydrate --directory ec
```

Or use a list of accessions (`datasets download genome accession --inputfile accs.txt`). The script
`workflows/pangenome_bacteria/01_download.sh` wraps this.

## Selection steps

1. **Collect candidates** and save the accession list.
2. **Check taxonomy.** Confirm with ANI against a representative genome. Remove anything below your species cutoff.
3. **Check assembly level and size.** Remove genomes far from the median size.
4. **Remove duplicates and near-identical clones.**
5. **Record metadata** for each kept genome.
6. **Keep a log of excluded genomes with the reason.**

## Selection criteria for bacteria (starting values)

| Criterion | Starting cutoff |
| --- | --- |
| Completeness (CheckM2) | 95% or higher |
| Contamination | 5% or lower |
| Contigs (draft) | under about 200 to 500 |
| Genome size | within about 10 to 20% of the species median |
| ANI to species representative | about 95% or higher |
| Plasmid-only or MAG records | exclude unless that is your question |

Adjust and justify these for your species.

## Selection criteria for eukaryotes (starting values)

| Criterion | Starting cutoff |
| --- | --- |
| BUSCO complete | high and similar across assemblies (for example above 95% for plants) |
| Contiguity | contig N50 and chromosome-level scaffolding reported |
| Annotation | same pipeline for all assemblies, or re-annotate |
| Genome size | consistent with flow cytometry estimates where known |

## Common problems

- **Mixed annotation sources** create false accessory genes. Re-annotate everything the same way.
- **Contamination** adds foreign genes to the cloud genome. Check with CheckM2, BUSCO duplicated genes, or taxonomic classification.
- **Mislabelled species** in public databases. Always verify.
