# 4. Pan-genome construction

Choose the method that matches your organisms and question.

| Method | Best for | Idea |
| --- | --- | --- |
| **Panaroo** | bacteria, draft assemblies | graph-based; corrects fragmented genes and annotation errors |
| **PPanGGOLiN** | bacteria at scale | clusters, then partitions persistent/shell/cloud statistically; uses gene neighbourhood |
| **Roary** | quick bacterial runs | fast, simple; sensitive to annotation errors |
| **OrthoFinder** | eukaryotes, divergent species | orthogroups from proteomes; gene trees and duplication events |
| **MMseqs2 / CD-HIT** | very large sets, custom pipelines | fast protein clustering at set identity and coverage |
| **Graph pangenome** | structural variants, populations | see `06-graph-pangenomes-and-sv.md` |

## Bacteria with Panaroo

```bash
panaroo -i ann/*/*.gff3 -o results/panaroo \
  --clean-mode strict -t 8 --remove-invalid-genes
# optional core alignment
panaroo -i ann/*/*.gff3 -o results/panaroo --clean-mode strict -t 8 \
  -a core --aligner mafft --core_threshold 0.98
```

Key outputs: `gene_presence_absence.csv`, `gene_presence_absence_roary.csv`, `gene_presence_absence.Rtab`,
`pan_genome_reference.fa`, `summary_statistics.txt`, and (with `-a core`) `core_gene_alignment.aln`.

Settings that matter:

- `--clean-mode strict` removes more suspected errors. `moderate` is a middle option and `sensitive` keeps more.
- Protein identity (default 0.98) and family threshold change family size. Test two settings and report both.

## Bacteria with PPanGGOLiN

```bash
# genomes.tsv: name<TAB>path_to_gff_or_gbff
ppanggolin workflow --anno genomes.tsv --output results/ppanggolin --cpu 8
```

Gives partitions, gene families, regions of genome plasticity, and spots of insertion, which help
find mobile elements and genomic islands.

## Eukaryotes with OrthoFinder

```bash
orthofinder -f proteomes_longest_isoform/ -t 16 -a 4 -M msa
```

Use one longest-isoform FASTA per accession. Orthogroups are your gene families. Build the presence/absence
matrix from `Orthogroups.GeneCount.tsv` (convert counts above 0 to 1).

## Custom clustering with MMseqs2

```bash
cat proteomes/*.faa > all.faa
mmseqs easy-cluster all.faa clu tmp --min-seq-id 0.9 -c 0.8 --cov-mode 0 --threads 16
python scripts/cluster2pav.py clu_cluster.tsv --out pav.tsv
```

`cluster2pav.py` assumes protein IDs start with the genome name followed by a separator. See the script header.

## Parameter choices to document

| Parameter | Typical range | Effect |
| --- | --- | --- |
| Protein identity | 70% to 98% | lower merges more diverged genes (smaller pan-genome) |
| Coverage | 70% to 90% | stricter coverage splits fragments |
| Core threshold | 95% to 100% | affects only the labels |
| Paralog handling | split or merge | changes family counts |

## Check your result

- Core size should be stable when you drop a few genomes at random.
- Cloud size inflated? Look for contamination, fragmented genes, or annotation mismatch.
- Compare two tools on the same data. Disagreement flags sensitive parameters.

## Deliverable

`pav.tsv` or `gene_presence_absence.Rtab` (rows = gene families, columns = genomes, values 0/1), a reference
FASTA of one representative per family, and a short methods paragraph with versions and parameters.
