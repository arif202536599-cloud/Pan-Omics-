# 6. Graph pangenomes and structural variants (expert)

Gene presence/absence tables lose positional information. A **pangenome graph** keeps all sequences as
paths through a graph, so insertions, deletions, inversions and complex loci are represented directly.

## When do you need a graph?

- You study structural variants or large regions, not only gene content.
- You want to genotype variants across many samples against all genomes at once.
- Your species has large, repeat-rich genomes (many crops) where a single reference loses information.

A gene-family table is enough for a bacterial gene-content study.

## Tools

| Tool | Role |
| --- | --- |
| Minigraph-Cactus (`cactus-pangenome`) | graph from assemblies with base-level alignment; used in the Human Pangenome work |
| PGGB | all-to-all alignment graph, unbiased by a reference |
| minigraph | fast, structural-variant graph |
| vg (giraffe) | map short reads to the graph, call variants |
| PanGenie | genotype known SVs from short reads |
| odgi, Bandage | inspect and visualize graphs |
| SyRI | synteny and rearrangements between two assemblies |

## Workflow sketch (assemblies to graph)

1. Choose a reference and prepare chromosome-level assemblies with consistent chromosome names.
2. Soft-mask repeats (EDTA or RepeatMasker).
3. Build the graph:

```bash
# seqfile.txt: sample<TAB>path_to_fasta
cactus-pangenome ./jobstore seqfile.txt --reference REF \
  --outDir out --outName pan --vcf --giraffe
```

4. Call and genotype: map short reads of new accessions with `vg giraffe`, genotype with the VCF.
5. Annotate SVs: intersect with gene models and repeats.
6. Validate a subset by PCR or long-read evidence (`docs/wet-lab/03`).

Resource note: graph building needs substantial memory and disk. Start with one chromosome.

## PAV without a graph (practical for crops)

1. Build a **non-redundant pan-genome**: assemble each accession, take sequences absent from the reference, remove redundancy, add them to the reference.
2. Map reads of each accession (minimap2 or bwa-mem2) to the pan-genome.
3. Compute coverage per gene with `mosdepth` or `samtools coverage`.
4. Call a gene present when coverage breadth passes a threshold (for example 90% of the gene covered at 1x or more) and absent when below a low cutoff (for example under 10%). Report your cutoffs.
5. Compare with an assembly-based call for a few accessions to estimate error.

## Pan-gene categories in eukaryotes

Common scheme: core (all accessions), softcore (for example 95% or more), dispensable (in some), private
(one accession). State the percentage cutoffs. Dispensable genes are often enriched for disease resistance and stress response.

## Expert pitfalls

- Reference bias in read mapping.
- Collapsed repeats and tandem arrays make copy-number calls unreliable.
- Assembly gaps look like deletions. Check coverage and long-read support.
- Annotation transfer across accessions can miss genes. Test with RNA-seq evidence.
