# 3. QC and annotation

## QC

```bash
seqkit stats -a genomes/*.fna > qc/seqkit_stats.tsv
checkm2 predict -t 8 -x fna --input genomes/ --output-directory qc/checkm2
skani triangle -t 8 genomes/*.fna -o qc/ani.txt
```

Eukaryotes: run BUSCO with a matching lineage dataset:

```bash
busco -i genome.fa -l viridiplantae_odb10 -m genome -o busco_genome -c 8
```

(Use the current lineage dataset release for your group. List them with `busco --list-datasets`.)

Decide keep or drop with the table in `02-retrieval-and-selection.md`. Write the result into `metadata.csv`.

## Annotation for bacteria

Pick one tool and annotate every genome with it.

- **Bakta:** current, database-backed, good consistency. Needs a database download.
- **Prokka:** older but still widely used and compatible with Roary and Panaroo.

```bash
bakta --db /path/to/bakta_db --threads 8 --prefix GENOME --output ann/GENOME genome.fna
```

Keep the `.gff3` for Panaroo and the `.faa` for protein-level work.

## Annotation for eukaryotes

Use the same pipeline and evidence for each assembly.

1. **Repeats:** EDTA or RepeatModeler, then soft-mask.
2. **Gene models:** BRAKER3 or Helixer, plus RNA-seq and protein evidence where available.
3. **Quality:** BUSCO in proteins mode, gene counts, exon counts, mean gene length compared across accessions.
4. **Isoforms:** keep the longest isoform per gene for clustering (for example with AGAT `agat_sp_keep_longest_isoform.pl`).

If assemblies already have published annotations from different pipelines, lift over or re-annotate before comparing gene content.

## Add function

```bash
emapper.py -i pan_reps.faa -o eggnog --cpu 8 --data_dir /path/to/eggnog_db
interproscan.sh -i pan_reps.faa -f tsv -cpu 8
```

Annotate only the **representative sequence of each gene family** (not every genome) to save time.

## Deliverable

A table of genomes that passed QC, the annotation files for each, and the QC log with reasons for exclusions.
