# 7. Visualization and reporting

## Figures most papers include

1. **Pan and core curves** with permutation ranges (from `heaps_law.py`).
2. **Category bar or pie chart** (core, soft core, shell, cloud).
3. **Tree plus matrix:** core-gene tree with gene presence/absence heatmap (iTOL, ggtree, Phandango).
4. **Functional bar chart** of COG categories for core versus accessory.
5. **Network or UpSet plot** for shared accessory genes between groups (UpSetR).
6. **Genomic island map** (clinker, PPanGGOLiN spot plots).
7. **Graph view** of one interesting locus (Bandage, odgi).

## Tools

- Python: matplotlib, seaborn. R: ggplot2, ggtree, pheatmap, UpSetR.
- Interactive: Anvi'o pangenome display, Phandango, Panache (for graph pangenomes).

## Reporting checklist

- Number of genomes screened, kept, and why others were dropped.
- Source and date of every dataset, with accessions.
- All tool versions and parameters.
- Core threshold and the number of genes in each category.
- Heaps alpha with permutation range and the number of permutations.
- Code and data availability: repository DOI (Zenodo), raw reads in SRA, tables in supplement.
- A negative-results note: analyses tried that did not work.

## Reproducible pipeline tips

- Wrap steps in Snakemake or Nextflow once your manual run works.
- Keep a `config.yaml` with every parameter.
- Run the pipeline from scratch on a clean machine before submission.
