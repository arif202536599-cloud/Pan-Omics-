# 5. Analysis

Input: a presence/absence matrix (`.Rtab`, rows = gene families, columns = genomes, 0/1) and a core-gene alignment.

## 5.1 Size and categories

```bash
python scripts/classify_pangenes.py results/panaroo/gene_presence_absence.Rtab --out results/categories
```

Outputs counts of core, soft core, shell, cloud and private families, and a per-gene table.

## 5.2 Open or closed? Heaps' law

```bash
python scripts/heaps_law.py results/panaroo/gene_presence_absence.Rtab --perms 100 --out results/heaps
```

The script shuffles genome order many times, tracks pan and core size as genomes are added, and fits
the new-genes-per-genome curve `n = k * N^(-alpha)` (the Tettelin approach).

- **alpha under 1:** open pan-genome (keeps growing).
- **alpha over 1:** closed (approaches a limit).

Caveats: the estimate depends on sampling, clustering parameters and annotation quality. Report the
confidence range from permutations, and never interpret alpha from fewer than about 10 genomes.

## 5.3 Phylogeny from core genes

```bash
iqtree2 -s core_gene_alignment.aln -m MFP -B 1000 -T AUTO
```

For recombining species, mask recombination first:

```bash
run_gubbins.py --prefix results/gubbins core_gene_alignment.aln
```

Use the Gubbins tree for downstream tests. Plot with iTOL, ggtree or FigTree and add the presence/absence matrix beside the tree.

## 5.4 Function of the pan-genome

1. Run eggNOG-mapper and InterProScan on one representative per family.
2. Compare COG categories between core and accessory sets (counts and proportions).
3. Run enrichment (clusterProfiler, topGO, or a Fisher test with multiple-test correction) on accessory sets, for example genes private to one lineage.
4. Remember the core set is usually enriched for housekeeping functions (translation, metabolism). Accessory genes often enrich for defense, mobile elements and niche adaptation.

## 5.5 Mobile elements, AMR and virulence

- Resistance genes: AMRFinderPlus (`amrfinder -n genome.fna`) or ABRicate.
- Virulence factors: VFDB through ABRicate.
- Plasmids and mobility: MOB-suite, geNomad for plasmids and phages.
- Genomic islands: PPanGGOLiN regions of genome plasticity, IslandViewer.
- Phages: PHASTEST or geNomad.

## 5.6 Gene-trait association (pan-GWAS)

```bash
scoary -g gene_presence_absence_roary.csv -t traits.csv -p 0.05
```

For larger sets or continuous traits use pyseer with a phylogenetic or kinship matrix.

Rules:

- Correct for population structure. Raw tests find lineage markers, not causal genes.
- Correct for multiple testing (Benjamini-Hochberg or Bonferroni).
- Treat results as candidates for validation (`docs/wet-lab/03`).

## 5.7 Gene order and synteny

- Use PPanGGOLiN spots, or compare gene neighbourhoods with clinker.
- For eukaryotes, use SyRI or MCScanX for synteny and rearrangements.

## 5.8 Rarefaction and robustness checks

- Drop 10% of genomes at random, repeat five times, compare core size.
- Re-run with a second clustering setting.
- Compare complete genomes only versus the full set.

## Deliverables

Category counts, Heaps' alpha with range, core tree, enrichment tables, candidate gene list with evidence.
