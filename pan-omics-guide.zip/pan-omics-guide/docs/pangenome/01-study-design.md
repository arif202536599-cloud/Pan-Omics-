# 1. Study design

Decide these before touching data. Write the answers in your notebook (`templates/lab_notebook_template.md`).

## Questions to answer

1. **What is the biological question?** Examples: Is the species open? Which genes explain host range, resistance, yield or stress tolerance? Which genes are lineage specific?
2. **What is the unit?** Species, sub-species, serovar, cultivar panel, or population.
3. **How many genomes?** Rough guide for bacteria: 20 to 50 for a first descriptive study, hundreds for gene-trait association. Eukaryote panels are usually 10 to 100 chromosome-level assemblies.
4. **What sequencing level do you need?**
   - Complete or chromosome-level assemblies give the cleanest gene content and structural variants.
   - Draft short-read assemblies are fine for gene presence/absence if QC is strict.
5. **What metadata do you need?** Source, host, country, date, phenotype, antibiotic data, cultivar traits.
6. **What will you do with the result?** Descriptive paper, marker design, trait mapping, vaccine or drug target search, breeding.

## Sampling strategy

- Cover the **diversity** of the group, not only the easiest-to-find genomes.
- Avoid clonal over-representation (for example 200 genomes from one outbreak). De-replicate at a high ANI (for example 99.9%) or subsample.
- Keep an **outgroup** (a close but distinct species) for rooting trees.
- Decide a rule for **reference genome** choice, for example the RefSeq representative genome.

## Pre-register your criteria

Write down, before analysis: inclusion rules, QC cutoffs, clustering identity and coverage, core threshold, and statistical tests. This stops silent changes after you see the results.

## Deliverable of this step

A one-page plan: question, genome source, number, inclusion/exclusion rules, QC cutoffs, tools, expected outputs.
