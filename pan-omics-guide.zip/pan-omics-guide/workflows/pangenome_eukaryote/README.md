# Eukaryote (plant or animal) pan-genome workflow

Use this checklist; most steps are heavy and run on a cluster. Details: `docs/pangenome/03`, `04`, `06`.

1. **Collect assemblies** for each accession (chromosome-level preferred). Record source and version.
2. **QC:** BUSCO (genome mode), contiguity (N50), size against flow-cytometry estimates.
3. **Mask repeats:** EDTA or RepeatModeler plus RepeatMasker.
4. **Annotate with one pipeline:** BRAKER3 or Helixer, with RNA-seq and protein evidence. Check BUSCO (protein mode).
5. **Keep longest isoform** per gene (AGAT `agat_sp_keep_longest_isoform.pl`).
6. **Cluster:** `bash ../pan_proteome/03_orthofinder.sh proteomes/` (orthogroups = gene families).
7. **Classify:** convert gene counts to 0/1, run `python ../../scripts/classify_pangenes.py` and `heaps_law.py`.
8. **Synteny and SVs:** SyRI (pairwise) or Minigraph-Cactus / PGGB for a graph.
9. **PAV from reads (large panels):** map reads to a non-redundant pan-genome, compute per-gene coverage, apply stated thresholds.
10. **Validate:** PCR across breakpoints or presence/absence primers, RNA-seq evidence (`docs/wet-lab/03`).

Record every parameter in a `config.yaml` and put the commands in Git.
