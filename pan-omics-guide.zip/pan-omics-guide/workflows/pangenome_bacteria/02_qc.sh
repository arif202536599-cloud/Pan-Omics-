#!/usr/bin/env bash
# QC: sequence stats, ANI, completeness/contamination.
# Usage: bash 02_qc.sh data/ecoli/genomes results/qc
# Needs: seqkit, skani, checkm2 (with its database installed: checkm2 database --download)
set -euo pipefail
GEN="${1:?genomes folder}"; OUT="${2:?output folder}"; T="${THREADS:-8}"
mkdir -p "$OUT"
seqkit stats -a -T "$GEN"/*.fna > "$OUT/seqkit_stats.tsv"
skani triangle -t "$T" "$GEN"/*.fna -o "$OUT/ani.txt"
checkm2 predict -t "$T" -x fna --input "$GEN" --output-directory "$OUT/checkm2"
echo "Open $OUT/checkm2/quality_report.tsv and $OUT/seqkit_stats.tsv."
echo "Apply the cutoffs from docs/pangenome/02-retrieval-and-selection.md and list kept genomes in keep.txt."
