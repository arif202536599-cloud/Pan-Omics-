#!/usr/bin/env bash
# Download genomes for one taxon with NCBI Datasets.
# Usage: bash 01_download.sh "Escherichia coli" data/ecoli
set -euo pipefail
TAXON="${1:?taxon name, e.g. \"Escherichia coli\"}"
OUT="${2:?output folder}"
mkdir -p "$OUT" && cd "$OUT"
datasets download genome taxon "$TAXON" \
  --assembly-level complete --assembly-source RefSeq \
  --include genome,gff3,protein --dehydrated --filename genomes.zip
unzip -q -o genomes.zip -d pkg
datasets rehydrate --directory pkg
mkdir -p genomes
find pkg -name "*_genomic.fna" -exec cp {} genomes/ \;
echo "Downloaded $(ls genomes | wc -l) genomes into $OUT/genomes"
echo "Next: record accessions in templates/metadata_template.csv, then run 02_qc.sh"
