#!/usr/bin/env bash
# Annotate every kept genome with the SAME tool. Bakta shown; swap in prokka if preferred.
# Usage: bash 03_annotate.sh keep.txt data/ecoli/genomes /path/to/bakta_db ann
# keep.txt: one genome file name per line (e.g. GCF_000005845.2_ASM584v2_genomic.fna)
set -euo pipefail
KEEP="${1:?keep list}"; GEN="${2:?genomes folder}"; DB="${3:?bakta db}"; OUT="${4:?output}"; T="${THREADS:-8}"
mkdir -p "$OUT"
while read -r f; do
  name="$(basename "$f" .fna)"
  [ -d "$OUT/$name" ] && { echo "skip $name"; continue; }
  bakta --db "$DB" --threads "$T" --prefix "$name" --output "$OUT/$name" "$GEN/$f"
done < "$KEEP"
echo "GFF3 files: $OUT/*/*.gff3"
