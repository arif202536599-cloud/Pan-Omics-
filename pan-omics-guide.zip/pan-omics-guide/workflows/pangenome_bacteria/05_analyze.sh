#!/usr/bin/env bash
# Categories, Heaps' law, core tree.
# Usage: bash 05_analyze.sh results/panaroo results/analysis
set -euo pipefail
PAN="${1:?panaroo folder}"; OUT="${2:?output folder}"; T="${THREADS:-8}"
HERE="$(cd "$(dirname "$0")" && pwd)"; SCR="$HERE/../../scripts"
mkdir -p "$OUT"
python "$SCR/classify_pangenes.py" "$PAN/gene_presence_absence.Rtab" --out "$OUT/categories"
python "$SCR/heaps_law.py" "$PAN/gene_presence_absence.Rtab" --perms 100 --out "$OUT/heaps"
iqtree2 -s "$PAN/core_gene_alignment.aln" -m MFP -B 1000 -T "$T" --prefix "$OUT/core_tree"
echo "For recombinant species also run: run_gubbins.py --prefix $OUT/gubbins $PAN/core_gene_alignment.aln"
