#!/usr/bin/env bash
# Build the pan-genome with Panaroo (strict clean mode) and a core-gene alignment.
# Usage: bash 04_panaroo.sh ann results/panaroo
set -euo pipefail
ANN="${1:?annotation folder}"; OUT="${2:?output folder}"; T="${THREADS:-8}"
panaroo -i "$ANN"/*/*.gff3 -o "$OUT" --clean-mode strict -t "$T" \
  --remove-invalid-genes -a core --aligner mafft --core_threshold 0.98
echo "See $OUT/summary_statistics.txt, gene_presence_absence.Rtab, core_gene_alignment.aln"
