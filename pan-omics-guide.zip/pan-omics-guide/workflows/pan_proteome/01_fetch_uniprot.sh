#!/usr/bin/env bash
# Download UniProt reference proteomes listed one ID per line (e.g. UP000000625).
# Usage: bash 01_fetch_uniprot.sh proteome_ids.txt data/proteomes
# Adds a GENOME| prefix to each header so clusters can be mapped back to genomes.
set -euo pipefail
LIST="${1:?file with one proteome ID per line}"; OUT="${2:?output folder}"
mkdir -p "$OUT"
while read -r id; do
  [ -z "$id" ] && continue
  curl -s "https://rest.uniprot.org/uniprotkb/stream?query=(proteome:${id})&format=fasta&compressed=false" \
    | awk -v g="$id" '/^>/{sub(/^>/,">" g "|")} {print}' > "$OUT/${id}.faa"
  echo "$id: $(grep -c '>' "$OUT/${id}.faa") proteins"
done < "$LIST"
