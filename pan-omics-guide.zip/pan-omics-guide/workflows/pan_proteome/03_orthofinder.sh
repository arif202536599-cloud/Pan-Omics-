#!/usr/bin/env bash
# Orthogroups with OrthoFinder (use one longest-isoform FASTA per genome).
# Usage: bash 03_orthofinder.sh data/proteomes
set -euo pipefail
IN="${1:?folder of .faa}"; T="${THREADS:-16}"
orthofinder -f "$IN" -t "$T" -a 4 -M msa
echo "Presence/absence: convert Orthogroups/Orthogroups.GeneCount.tsv (count > 0 -> 1); then run scripts/classify_pangenes.py"
