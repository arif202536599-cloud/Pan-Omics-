#!/usr/bin/env bash
# Cluster all proteins and make a PAV matrix.
# Usage: bash 02_cluster_mmseqs.sh data/proteomes results/pp 0.5 0.8
# args: proteome folder, output folder, min sequence identity, coverage
set -euo pipefail
IN="${1:?folder of .faa}"; OUT="${2:?output}"; ID="${3:-0.5}"; COV="${4:-0.8}"; T="${THREADS:-8}"
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$OUT"
cat "$IN"/*.faa > "$OUT/all.faa"
mmseqs easy-cluster "$OUT/all.faa" "$OUT/clu" "$OUT/tmp" --min-seq-id "$ID" -c "$COV" --cov-mode 0 --threads "$T"
python "$HERE/../../scripts/cluster2pav.py" "$OUT/clu_cluster.tsv" --out "$OUT/pav.tsv"
python "$HERE/../../scripts/classify_pangenes.py" "$OUT/pav.tsv" --out "$OUT/categories"
